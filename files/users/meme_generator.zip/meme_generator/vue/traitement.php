<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <?php include '../includes/header.php'; ?>
    </head>
    <body>
        <div class="container">
            <div class="jumbotron text-center">
                <img src="src/img/slime.png" alt="">
            </div>
            <div class="jumbotron text-center">
                <input type="text" name="" value="" required><br>
                <input type="text" name="" value="" class="mt-1">
            </div>
            <div class="text-center">
                <a href="resultat.php"><button type="button" class="btn btn-danger">Générer</button></a>
            </div>
        </div>
    </body>
</html>
