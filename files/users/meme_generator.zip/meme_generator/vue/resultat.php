<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <?php include '../includes/header.php'; ?>
        <script type="text/javascript" src="js/script.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="jumbotron text-center">
                <img src="src/img/slime.png" alt="">
            </div>
            <div class="jumbotron text-center">
                URL : <input type="text" name="" value=""><br>
                <a href="../index.php"><button type="button" class="btn btn-danger mt-2">Accueil</button></a>
            </div>
        </div>
    </body>
</html>
